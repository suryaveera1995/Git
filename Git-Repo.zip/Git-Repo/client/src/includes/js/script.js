/*

My Custom JS
============

Author:  Karan Gumber
Updated: December 2013
Notes:	 Hand coded for Hybrid Training

*/